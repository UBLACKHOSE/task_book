package d.fifth_zad;

import com.sun.org.apache.xerces.internal.xs.StringList;
import sun.misc.IOUtils;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class Main {
    private static String log_path = "./logs/logs.txt";
    private static String log_zip_path = "./logs/arch/logs";

    private static int log_save = 10;


    public static void main(String[] args) throws Exception {
        long time = 1000;
        long lasttime = System.currentTimeMillis();
        long delta = 1000;
        while (true) {
            time += System.currentTimeMillis()-lasttime;
            lasttime = System.currentTimeMillis();
            if(time >= delta){
                time = 0;
                writeLog();
                if(log_save <= 0){
                    log_save = 10;
                    zipLog();
                    clearLog();
                }else {
                    log_save--;
                }
            }
        }
    }

    private static void writeLog() throws IOException {
        List<String> lines = Arrays.asList(System.nanoTime()+"", new SimpleDateFormat("yyyy_MM_dd__HH-mm-ss").format(Calendar.getInstance().getTime()));
        Path file = Paths.get(log_path);
        File f = new File(file.toString());
        if(!f.exists())
            f.createNewFile();
        Files.write(file, lines, StandardCharsets.UTF_8, StandardOpenOption.APPEND);
    }

    private static void clearLog() throws IOException {
        Path file = Paths.get(log_path);
        File f = new File(file.toString());
        if(!f.exists())
            f.createNewFile();
        Files.write(file, new ArrayList<String>(), StandardCharsets.UTF_8);
    }


    private static void zipLog() throws IOException {
        String date = new SimpleDateFormat("yyyy_MM_dd__HH-mm-ss").format(Calendar.getInstance().getTime());
        Path file = Paths.get(log_path);
        File f = new File(file.toString());
        if(!f.exists())
            f.createNewFile();
        FileInputStream in = new FileInputStream(log_path);
        ZipOutputStream out = new ZipOutputStream(new FileOutputStream(log_zip_path+date+".zip"));
        out.putNextEntry(new ZipEntry("old_logs_"+date+".txt"));
        byte[] bytes = Files.readAllBytes(file);
        int count;

        while ((count = in.read(bytes))>0)
            out.write(bytes, 0, count);

        out.close();
        in.close();
    }
}
